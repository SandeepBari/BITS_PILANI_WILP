 /* Sandeep Bari
   2021HT65677
   M.Tech in Automotive Electronics
*/

// Assignment 1- Program 3

/* Read the ADC and display the value in LCD in the range 0 to 15.0 (display decimal value)
   when the voltage is increased from 0 to 5V at the analog input.
   If the voltage goes below 10.5 display the message LOW VOLTAGE in the second line.
   If the voltage goes above 13.5V display the message HIGH VOLTAGE. At other times display the message NORMAL.
   Follow the submission guidelines.
*/


// Functions Initialization
void ADC_LCD_Init(void);
void LCD_Command(unsigned char);
void LCD_Data(unsigned char);
void LCD_Output(unsigned int);
void LCD_Display(unsigned char *string);

// Variables Initialization
unsigned char ADC_Data[3];
unsigned int Voltage,Value;

void main()
{
  ADC_LCD_Init();                    // ADC and LCD Initialization

  while(1)
   {
     ADCON0 = 0x81;                   // Configure the A/D control registers
     ADCON0 |= 0x04;                  // Start ADC conversion
     while(ADCON0&0x04);              // Wait for conversion to complete

     Value = (ADRESH << 8) | ADRESL;  // Load the 10bit result into Value
     Voltage = (Value*0.1466);        // Scale the value to the range 0 to 48
     LCD_Output(Voltage);             // LCD display function is called
     Delay_ms(5);                     // Delay of 5 millisecond
   }
}

void ADC_LCD_Init(void)   // Initialization
{
  TRISA = 0X01;           // PORTA RA0 is made as input
  TRISD = 0X00;           // PORTD is made as output
  TRISE = 0x00;           // PORTE is made as output
  ADCON0 = 0X81;          // Configure the A/D control registers
  ADCON1 = 0X8E;
  LCD_Command(0x38);      // Initialize the 2 lines and 5*7 Matrix LCD
  LCD_Command(0x06);      // Increment cursor (shift cursor to right)
  LCD_Command(0x0C);      // Display on, cursor off
  LCD_Command(0x01);      // Clear display screen
}

void LCD_Output(unsigned int i)
{
  LCD_Command(0x80);                    // Cursor at First Line of LCD
  ADC_Data[0] = (i%1000)/100 + 0x30;    // First Character
  ADC_Data[1] = (i%100)/10 + 0x30;      // Second Character
  ADC_Data[2] = (i%10) + 0x30;          // Third Character
  LCD_Data(ADC_Data[0]);                // Writing the First Character
  LCD_Data(ADC_Data[1]);                // Writing the Second Character
  LCD_Data(0x2E);                       // Writing '.'
  LCD_Data(ADC_Data[2]);                // Writing the Third Character
  LCD_Display("V");                     // Display 'V'

  LCD_Command(0xC0);                    // Cursor at Second Line of LCD

  if (i >= 0 &&  i< 105)                // Voltage Range between 0V to 10.5V showing Low Voltage
    LCD_Display("LOW VOLTAGE   ");

  if (Voltage >= 105 && Voltage <= 135) // Voltage Range between 10.5V to 13.5V showing Normal Voltage
    LCD_Display("NORMAL VOLTAGE");

  if (Voltage > 135)                    // Voltage Range between 13.5V to 15V showing High Voltage
    LCD_Display("HIGH VOLTAGE  ");
}

void LCD_Command(unsigned char i)
{
  PORTE &= ~(0x04);        // RS=0
  PORTD = i;
  PORTE |= 0x02;           // RS=0, R/W=0, EN=1
  PORTE &= ~(0x02);        // RS=0, R/W=0, EN=0
  Delay_ms(5);             // Delay of 5 millisecond
}

void LCD_Data(unsigned char i)
{
  PORTE |= 0x04;           // RS=1
  PORTD = i;
  PORTE |= 0x02;           // RS=1, R/W=0, EN=1
  PORTE &= ~(0x02);        // RS=0, R/W=0, EN=0
  Delay_ms(5);             // Delay of 5 millisecond
}

void LCD_Display(unsigned char *string)   // Display String
{
  while(*string)           // Run untill all the characters are done
     LCD_Data(*string++);  // Character Increment

  Delay_ms(5);             // Delay of 5 millisecond
}