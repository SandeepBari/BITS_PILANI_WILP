/* Sandeep Bari
   2021HT65677
   M.Tech in Automotive Electronics
*/

// Assignment 1- Program 2

/* Display the number 1234 in the 7 segment display. 
   If the switch connected to RB0 is pressed continuous increment the number at 1 second interval until the number reaches 1250 and stays at that number.
   If the switch connected to RB1 is pressed continuous, decrement the number by 1 at 1 second interval until the number reaches 1200 and stays there. 
   If the switch connected to RB2 is pressed at any time display the number 1234. Follow the submission guidelines.
*/

unsigned char tableDigit[10]= {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0X7F,0x6f}; // Array containg Hex Value from 0-9
char countTemp= 34;           // Counter initialized to 34
unsigned char digit3= 0x4F;   // Digit 3 initialized to 3
unsigned char digit4= 0x66;   // Digit 4 initialized to 4

void main()
{
  TRISB = 0x07;               // PORTB as Intput
  TRISD = 0x00;               // PORTD as Output
  TRISA = 0x00;               // PORTA as Output
  ADCON1 = 0x06;              // Configuration Register of PORTA

  while(1)
  {
    PORTA = 0x04;             // Set RA2 logic high - Common Cathode
    PORTD = 0x06;             // 1st Digit
    Delay_ms(1);              // Delay one millisecond

    PORTA = 0x08;             // Set RA3 logic high - Common Cathode
    PORTD = 0x5B;             // 2nd Digit
    Delay_ms(1);              // Delay one millisecond

    PORTA = 0x10;             // Set RA4 logic high - Common Cathode
    PORTD = digit3;           // 3rd Digit
    Delay_ms(1);              // Delay one millisecond

    PORTA = 0x20;             // Set RA5 logic high - Common Cathode
    PORTD = digit4;           // 4th Digit
    Delay_ms(1);              // Delay one millisecond
   
    if (PORTB.B2 == 0)        // To check if RB2 is pressed
     {
       countTemp = 34;        // Reset Counter to 1234
       digit3 = 0x4F;         // To Display 1234
       digit4 = 0x66;
     }
    
    if (PORTB.B0 == 0 && countTemp < 51)                // To check if RB0 is pressed
     {
       delay_ms(1000);                                  // One second Delay
       if (PORTB.B0 == 0 && countTemp <= 49)            // To check if the key is pressed for one second and if less than equal to 1250
        {
          countTemp++;                                  // Counter Increment
          digit4 = tableDigit[countTemp % 10];          // 4th Digit
          digit3 = tableDigit[(countTemp / 10) % 10];   // 3rd Digit
        }
     }
    
    if (PORTB.B1 == 0)    // To check if RB1 is pressed
     {
       delay_ms(1000);    // One second Delay
       if (PORTB.B1 == 0) // To check if the key is pressed for one second
       {
         countTemp--;     // Counter Decrement
         
         if (countTemp != 0 && countTemp > 0 && countTemp < 51)
         {
           digit4 = tableDigit[countTemp % 10];         // 4th Digit
           digit3 = tableDigit[(countTemp / 10) % 10];  // 3rd Digit
         }
        
         if (countTemp == 0 || countTemp > 51)         // Check not to display below 1200
         {
           digit3= 0x3F;                               // Display 1200
           digit4= 0x3F;
         }
        }
      }
   }
}