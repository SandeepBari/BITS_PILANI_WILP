/* Sandeep Bari
   2021HT65677
   M.Tech in Automotive Electronics
*/

// Assignment 1- Program 1

/*Three switches are connected to PORTB pins RB0, RB1 and RB2.
We would like to show the vehicle turn indicator and hazard light signals using these keys with the following rules.
Write a single program that performs the following functions.
When the key connected to RB0 is pressed, the LEDs connected to RD7 and RD6 will blink at 1 second interval.
When the key connected to RB1 is pressed, the LEDs connected to RD0 and RD1 will blink at 1 second interval.
When the key RB2 is pressed, then the LEDs connected to RD0, RD1, RD2, RD5, RD6 and RD7 will blink at 1 second interval.
Test the program and take relevant screen shots of the output from PICSIMLAB. Follow the submission guidelines.
*/

void Blink(unsigned char LED_Sel)
{
  PORTD= LED_Sel;  // PORTD/ LED Selection
  delay_ms(1000); // One second delay
  PORTD= 0x00;    // All LEDs are OFF
  delay_ms(1000); // One second delay
}

void main()
{
  int buttonPressedCheck= 3;  // Default Initialization
  TRISB= 0x07; //PORTB as Intput
  TRISD= 0x00; //PORTD as Output

  while(1)
  {
   if (PORTB.B0 == 0 || buttonPressedCheck== 0)
    {
      buttonPressedCheck= 0;
      Blink(0xC0); // RD7 and RD6 will blink
    }

    if (PORTB.B1 == 0 || buttonPressedCheck== 1)
    {
      buttonPressedCheck= 1;
      Blink(0x03); // RD0 and RD1 will blink
    }

    if(PORTB.B2 == 0 || buttonPressedCheck== 2)
    {
      buttonPressedCheck= 2;
      Blink(0xE7); // RD0, RD1, RD2, RD5, RD6 and RD7 will blink
    }
  }
}