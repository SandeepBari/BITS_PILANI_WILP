/* Sandeep Bari
   2021HT65677
   M.Tech in Automotive Electronics
*/

// Assignment 1- Program 2

/* Display the number 1234 in the 7 segment display. 
   If the switch connected to RB0 is pressed continuous increment the number at 1 second interval until the number reaches 1250 and stays at that number.
   If the switch connected to RB1 is pressed continuous, decrement the number by 1 at 1 second interval until the number reaches 1200 and stays there. 
   If the switch connected to RB2 is pressed at any time display the number 1234. Follow the submission guidelines.
*/

unsigned char tableDigit[10]= {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0X7F,0x6f}; // Array containg Hex Value from 0-9
unsigned int countTemp= 1234;                   // Counter initialized to 1234
void sevenSegDisplay(unsigned int countTemp);   // Function Declaration

void main()
{ 
  TRISB = 0x07;               // PORTB as Intput
  TRISD = 0x00;               // PORTD as Output
  TRISA = 0x00;               // PORTA as Output
  ADCON1 = 0x06;              // Configuration Register of PORTA

  while(1)
  {
    if (PORTB.B2 == 0)        // To check if RB2 is pressed
      countTemp = 1234;       // Reset Counter to 1234
    
    if (PORTB.B0 == 0 && countTemp < 1250) // To check if RB0 is pressed
     {
       Delay_ms(1000);                     // One second Delay
       if (PORTB.B0 == 0)                  // To check if the key is pressed for one second
          countTemp++;                     // Counter Increment
     }
    
    if (PORTB.B1 == 0 && countTemp > 1200) // To check if RB1 is pressed
     {
       Delay_ms(1000);                     // One second Delay
       if (PORTB.B1 == 0)                  // To check if the key is pressed for one second
         countTemp--;                      // Counter Decrement
     }
      
     sevenSegDisplay(countTemp);          // Display 'countTemp'
   }
   
}

void sevenSegDisplay(unsigned int countTemp)
{
    PORTA = 0x04;                               // Set RA2 logic high - Common Cathode
    PORTD = tableDigit[(countTemp / 1000)];     // 1st Digit- Thousand's Place
    Delay_ms(1);                                // Delay one millisecond

    PORTA = 0x08;                               // Set RA3 logic high - Common Cathode
    PORTD = tableDigit[(countTemp / 100) % 10]; // 2nd Digit- Hundred's Place
    Delay_ms(1);                                // Delay one millisecond

    PORTA = 0x10;                               // Set RA4 logic high - Common Cathode
    PORTD = tableDigit[(countTemp / 10) % 10];  // 3rd Digit- Ten's Place
    Delay_ms(1);                                // Delay one millisecond

    PORTA = 0x20;                               // Set RA5 logic high - Common Cathode
    PORTD = tableDigit[countTemp % 10];         // 4th Digit- Unit Place 
    Delay_ms(1);                                // Delay one millisecond
}